history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
ls -la /root
apt update
vi /etc/apt/sources.list
apt update
vi /etc/hostname
vi /etc/hostname
shutdown now
apt upgrade
SHUTDOWN NOW
shutdown now
apt update
aptcat /etc/os-release
cat /etc/os-relsease
df -h /
cat /etc/apt/sources.list
apt clean
rm -rf /var/lib/apt/lists/*
apt update --allow-releaseinfo-change
apt upgrade
apt full-upgrade
apt autoremove
apt clean
dpkg --audit
cat /etc/os-release
vi /etc/apt/sources.list
apt clean
rm -rf /var/lib/apt/lists/*
apt update --allow-releaseinfo-change
apt upgrade --without-new-pkgs
apt full-upgrade
dpkg --configure -a
apt --fix-broken install
apt autoremove
apt clean
cat /etc/os-release
shutdown now
exit
exit
exit
root
apt-get update
apt-get install openssh-server
systemctl status ssh
cd /root
tar -xzvf Material_Adicional_TPVMCA.tar.gz
mkdir -p /root/.ssh
cat /root/Material_Adicional_TPVMCA/clave_publica.pub > /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
ls -ls /root/.ssh
vi /etc/ssh/sshd_config
sshd -t
systemctl restart ssh
systemctl status ssh
ip a
vi /etc/ssh/sshd_config
sshd -t
systemctl restart ssh
systemctl status ssh
shutdown now
mariadb -e "SELECT * FROM alumnos;"
mariadb -e "SELECT * FROM ingenieria.alumnos;"
systemctl restart apache2
curl -I http://localhost/index.php
curl -I http://localhost/logo.png
shutdown now
vi /etc/network/interfaces
systemctl restart networking
ip a
ip route
ping -c 192.168.1.1
ping -c 4 192.168.1.1
ping -c 4 8.8.8.8
ping -c 4 deb.debian.org
shutdown now
vi /etc/apache2/apache2.conf
apache2ctl configtest
systemctl restartsystemctl restart apache2
systemctl restart apache2
curl -I http://localhost/index.php
curl -I http://localhost/logo.png
ls -la /www_dir
cp /root/Material_Adicional_TPVMCA/index.php /www_dir/
cp /root/Material_Adicional_TPVMCA/logo.png /www_dir/
ls -la /www_dir
systemctl restart apache2
curl -I http://localhost/index.php
curl -I http://localhost/logo.png
blkid /dev/sdc1 /dev/sdc2
vi /etc/fstab
mount -a
blkid /dev/sdc1 /dev/sdc2
vi /etc/fstab
systemctl daemon-reload
mount -a
df -h /www_dir /backup_dir
lsblk
curl -I http://localhost/index.php
reboot
lsblk
cat /proc/partitions > /opt/particion
ls -l /opt/particion
cat /opt/particion
shutdown now
mkdir -p /opt/scripts
ls -ld /opt/scripts
shutdown now
