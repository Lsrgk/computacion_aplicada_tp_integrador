#!/bin/bash

#Funcion -help
mostrar_ayuda(){
	echo "Uso: $0 /var/log /backup_dir"
	echo "Ejemplo: $0 /var/log /backup_dir"
}


#Funcion para realizar la compresion
compresion(){ 
	FECHA=$(date +%Y%m%d)
	NOMBRE_BASE=$(basename "$1")
	NOMBRE_ARCHIVO="${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"
	
	#Ejecucion del comando tar preservando permisos
	tar -czpf "$2/$NOMBRE_ARCHIVO" -C "$(dirname "$1")" "$NOMBRE_BASE"

	if [[ $? -eq 0 ]]; then
		echo "Backup creado con exito en $2/$NOMBRE_ARCHIVO"
	else
		echo "Error al crear backup "
	fi
}


#Logica principal
#Si se escribe -help, se muestra la ayuda
if [[ "$1" == "-help"  ]]; then
	mostrar_ayuda
#Se pasa a comprobar los argumentos
elif [ $# -ne 2 ];then
	echo "Error: Argumentos incorrectos. (-help para mas informacion)"
#Si son dos argumentos entonces valido los directorios
else
	ORIGEN=$1
	DESTINO=$2

	#Validamos si ambos directorios existen
	if [ -d "$ORIGEN" ] && [ -d "$DESTINO" ];then

		#Se ejecuta el script en caso de que todo este OK
		compresion "$ORIGEN" "$DESTINO"
	else
		echo "ERROR: El origen o el destino no estan disponibles o no existen."
	fi
fi

